# Nowhere Dreams (fan mod, Forge 1.20.1 · Java Edition)

Requisitos: JDK 17 y Gradle (o IntelliJ IDEA, que lo descarga solo).

## Compilar
1. Abre la carpeta en IntelliJ IDEA (Open → build.gradle) y espera a que sincronice,
   o en terminal: `gradle genIntellijRuns` y luego `gradle build`.
2. El .jar sale en `build/libs/`. Cópialo a la carpeta `mods` de Forge 1.20.1 (47.x).
3. Para probar directamente: `gradle runClient`.

## Cómo se juega
- Crea la **Llave Onírica** (amatista en cruz + perla de ender al centro) o sácala de la pestaña creativa "Nowhere Dreams".
- Clic derecho: Overworld → Liminal Halls → Dream Void → Beta Lands → Overworld (60 ticks de espera).
- Cada dimensión tiene una sola criatura (ver `ModDimensions.creatureFor`): Backrooms 92 = Locust, Liminal Halls = figura blanca, Dream Void = Sentado del Cono, Beta Lands = Boca Roja.

## Dónde tocar cosas
- Estadísticas / efectos de cada criatura: `CreatureVariant.java`
- Dibujo y animaciones (balanceo, respiración, glitch): `client/DreamCreatureRenderer.java`
- Niebla, FOV y cámara dreamcore: `client/DreamClientEvents.java`
- Dimensiones: `src/main/resources/data/nowheredreams/dimension*/`
- Imágenes de las criaturas (tus PNG recortados): `assets/nowheredreams/textures/entity/*.png`. Si cambias una, actualiza su `aspect` (ancho/alto) en `CreatureVariant.java`

## Dimensión Backrooms 92
- Ir: `/execute in nowheredreams:backrooms_92 run tp @s 0 30 0` (antes: `/effect give @s minecraft:slow_falling 15`) o con la Llave Onírica.
- Colinas redondas, casas retro y molinetes gigantes. Solo aparece la Locust.

## Reglas por dimensión
- Liminal Halls: El Coronado Blanco · Dream Void: El Velado · Beta Lands: El Sombrerero de Brazos · Backrooms 92: Locust, figura blanca y Boca Roja (la excepción).
- El Sentado (cone_sitter) es un personaje: si te acercas, te lleva a Backrooms 92.
- Cada 2 minutos puede aparecer una Puerta Onírica (dura 60 s): te lleva a un nivel al azar. `/summon nowheredreams:dream_door` para probarla.

## Salidas de cada nivel
- Liminal Halls: usar una cama (hay una en cada casa).
- Dream Void: caer al vacío.
- Beta Lands: llegar al techo de nubes (la caja celeste tiene paredes con nubes y no se puede salir por los lados).
- Backrooms 92: clic derecho en el centro naranja de un molinete.
- Si una criatura te mata: susto a pantalla completa con su imagen (3 s).
