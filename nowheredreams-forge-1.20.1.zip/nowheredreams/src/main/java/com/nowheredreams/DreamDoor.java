package com.nowheredreams;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.NetworkHooks;

/** Puerta que aparece cada cierto tiempo: al acercarte te lleva a un nivel al azar. Dura 60 segundos. */
public class DreamDoor extends Entity {
    public DreamDoor(EntityType<? extends DreamDoor> type, Level level) {
        super(type, level);
        this.noPhysics = true;
    }

    @Override protected void defineSynchedData() {}
    @Override protected void readAdditionalSaveData(CompoundTag tag) {}
    @Override protected void addAdditionalSaveData(CompoundTag tag) {}

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        if (tickCount > 1200) { discard(); return; }
        Player p = level().getNearestPlayer(this, 1.6);
        if (p instanceof ServerPlayer sp && !sp.isSpectator()) {
            ModDimensions.travel(sp, ModDimensions.randomOther(level().dimension(), random));
            discard();
        }
    }
}
