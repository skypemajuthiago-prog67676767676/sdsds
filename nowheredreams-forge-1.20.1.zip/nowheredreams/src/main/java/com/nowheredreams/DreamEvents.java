package com.nowheredreams;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.network.PacketDistributor;

/** Salidas de cada nivel, límites de la caja de Beta y animación de muerte. */
public class DreamEvents {

    /** Cuando una criatura te mata: susto a pantalla completa + sonido. */
    @SubscribeEvent
    public void onDeath(LivingDeathEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp
                && e.getSource().getEntity() instanceof DreamCreature dc
                && dc.getVariant() != CreatureVariant.CONE) {
            Net.CHANNEL.send(PacketDistributor.PLAYER.with(() -> sp), new JumpscarePacket(dc.getVariant().ordinal()));
            sp.serverLevel().playSound(null, sp.blockPosition(), SoundEvents.ELDER_GUARDIAN_CURSE, SoundSource.HOSTILE, 2.0f, 0.5f);
        }
    }

    /** Liminal Halls: usar una cama.  Backrooms 92: tocar el centro naranja de un molinete. */
    @SubscribeEvent
    public void onRightClick(PlayerInteractEvent.RightClickBlock e) {
        if (e.getLevel().isClientSide || !(e.getEntity() instanceof ServerPlayer sp)) return;
        ResourceKey<Level> dim = e.getLevel().dimension();
        BlockState st = e.getLevel().getBlockState(e.getPos());
        boolean exit = (dim == ModDimensions.LIMINAL && st.getBlock() instanceof BedBlock)
                || (dim == ModDimensions.BACKROOMS && st.is(Blocks.ORANGE_CONCRETE));
        if (exit) {
            e.setCanceled(true);
            ModDimensions.travel(sp, Level.OVERWORLD);
        }
    }

    /** Dream Void: caer al vacío.  Beta Lands: llegar al techo; además no puedes salir de la caja. */
    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer sp)) return;
        ResourceKey<Level> dim = sp.level().dimension();

        if (dim == ModDimensions.VOID && sp.getY() < -8) {
            sp.fallDistance = 0;
            ModDimensions.travel(sp, Level.OVERWORLD);
        } else if (dim == ModDimensions.BETA) {
            if (sp.getY() >= com.nowheredreams.worldgen.DreamFeatures.BOX_TOP - 3) {
                ModDimensions.travel(sp, Level.OVERWORLD);
                return;
            }
            double lim = com.nowheredreams.worldgen.DreamFeatures.BOX_R - 1.0;
            double x = Mth.clamp(sp.getX(), -lim, lim), z = Mth.clamp(sp.getZ(), -lim, lim);
            if (x != sp.getX() || z != sp.getZ())
                sp.connection.teleport(x, sp.getY(), z, sp.getYRot(), sp.getXRot());
        }
    }
}
