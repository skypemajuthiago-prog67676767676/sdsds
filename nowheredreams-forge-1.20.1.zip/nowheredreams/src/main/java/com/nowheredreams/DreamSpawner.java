package com.nowheredreams;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * Cada lugar tiene su propia criatura:
 *  - Liminal Halls -> El Coronado Blanco
 *  - Dream Void    -> El Velado
 *  - Beta Lands    -> El Sombrerero de Brazos
 *  - Backrooms 92  -> Locust, figura blanca y Boca Roja (la excepción: tiene tres)
 * El Sentado (personaje) aparece en los 3 primeros y te lleva a Backrooms 92.
 * Cada 2 minutos puede aparecer una puerta que lleva a un nivel al azar.
 */
public class DreamSpawner {

    private static CreatureVariant pick(ResourceKey<Level> dim, ServerLevel level) {
        if (dim == ModDimensions.BACKROOMS) {
            float roll = level.random.nextFloat();
            return roll < 0.5f ? CreatureVariant.STILT : roll < 0.8f ? CreatureVariant.BATH_GIANT : CreatureVariant.RED_MAW;
        }
        if (dim == ModDimensions.LIMINAL) return CreatureVariant.WHITE_CROWN;
        if (dim == ModDimensions.VOID) return CreatureVariant.VEILED;
        return CreatureVariant.MANY_ARMS; // Beta Lands
    }

    /** Punto sobre el suelo a cierta distancia del jugador, o null si no hay suelo / chunk cargado. */
    private static BlockPos ground(ServerLevel level, ServerPlayer p, double minDist, double maxDist) {
        double ang = level.random.nextDouble() * Math.PI * 2;
        double dist = minDist + level.random.nextDouble() * (maxDist - minDist);
        int x = (int) (p.getX() + Math.cos(ang) * dist);
        int z = (int) (p.getZ() + Math.sin(ang) * dist);
        if (!level.hasChunkAt(new BlockPos(x, p.getBlockY(), z))) return null;
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
        if (y <= level.getMinBuildHeight() + 1) return null;
        return new BlockPos(x, y, z);
    }

    @SubscribeEvent
    public void onLevelTick(TickEvent.LevelTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.level instanceof ServerLevel level)) return;
        ResourceKey<Level> dim = level.dimension();
        if (!ModDimensions.isDream(dim)) return;
        long time = level.getGameTime();

        if (time % 100 == 0) {
            for (ServerPlayer p : level.players()) {
                spawnCreature(level, p, dim);
                if (dim != ModDimensions.BACKROOMS) spawnSitter(level, p);
            }
        }
        if (time % 2400 == 0) {
            for (ServerPlayer p : level.players())
                if (level.random.nextFloat() < 0.7f) spawnDoor(level, p);
        }
    }

    private void spawnCreature(ServerLevel level, ServerPlayer p, ResourceKey<Level> dim) {
        long nearby = level.getEntitiesOfClass(DreamCreature.class, p.getBoundingBox().inflate(64)).stream()
                .filter(c -> c.getVariant() != CreatureVariant.CONE).count();
        if (nearby >= 3 || level.random.nextFloat() > 0.45f) return;
        BlockPos pos = ground(level, p, 26, 40);
        if (pos == null) return;
        spawn(level, pick(dim, level), pos);
    }

    private void spawnSitter(ServerLevel level, ServerPlayer p) {
        boolean exists = !level.getEntitiesOfClass(DreamCreature.class, p.getBoundingBox().inflate(64),
                c -> c.getVariant() == CreatureVariant.CONE).isEmpty();
        if (exists || level.random.nextFloat() > 0.15f) return;
        BlockPos pos = ground(level, p, 14, 24);
        if (pos == null) return;
        spawn(level, CreatureVariant.CONE, pos);
    }

    private void spawnDoor(ServerLevel level, ServerPlayer p) {
        BlockPos pos = ground(level, p, 5, 8);
        if (pos == null) return;
        DreamDoor door = new DreamDoor(NowhereDreams.DOOR.get(), level);
        door.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, 0f, 0f);
        level.addFreshEntity(door);
    }

    private void spawn(ServerLevel level, CreatureVariant v, BlockPos pos) {
        DreamCreature mob = NowhereDreams.CREATURES.get(v).get().create(level);
        if (mob == null) return;
        mob.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, level.random.nextFloat() * 360f, 0f);
        level.addFreshEntity(mob);
    }
}
