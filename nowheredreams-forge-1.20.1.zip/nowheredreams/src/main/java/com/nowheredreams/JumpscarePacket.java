package com.nowheredreams;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/** Servidor -> cliente: "muestra el susto de esta criatura". */
public class JumpscarePacket {
    private final int variant;

    public JumpscarePacket(int variant) { this.variant = variant; }

    public static void encode(JumpscarePacket msg, FriendlyByteBuf buf) { buf.writeVarInt(msg.variant); }
    public static JumpscarePacket decode(FriendlyByteBuf buf) { return new JumpscarePacket(buf.readVarInt()); }

    public static void handle(JumpscarePacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.nowheredreams.client.Jumpscare.start(msg.variant)));
        ctx.get().setPacketHandled(true);
    }
}
