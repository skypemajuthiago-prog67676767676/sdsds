package com.nowheredreams.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.nowheredreams.CreatureVariant;
import com.nowheredreams.NowhereDreams;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Animación de muerte: destello rojo + la imagen de la criatura que te mató, grande y temblando (3 s). */
@Mod.EventBusSubscriber(modid = NowhereDreams.MODID, value = Dist.CLIENT)
public class Jumpscare {
    /** Tamaño en píxeles de cada imagen, en el orden de CreatureVariant. */
    private static final int[] TEX_W = {67, 73, 55, 153, 165, 251, 50};
    private static final int[] TEX_H = {256, 256, 256, 256, 256, 256, 256};
    private static final long DURATION_MS = 3200;

    private static long start = -1;
    private static CreatureVariant variant;

    public static void start(int ordinal) {
        variant = CreatureVariant.values()[ordinal];
        start = Util.getMillis();
    }

    /** Sobre la pantalla de muerte. */
    @SubscribeEvent
    public static void onScreen(ScreenEvent.Render.Post e) {
        draw(e.getGuiGraphics(), e.getScreen().width, e.getScreen().height);
    }

    /** Si no hay pantalla abierta (por ejemplo con respawn inmediato). */
    @SubscribeEvent
    public static void onHud(RenderGuiEvent.Post e) {
        if (Minecraft.getInstance().screen != null) return;
        draw(e.getGuiGraphics(), e.getWindow().getGuiScaledWidth(), e.getWindow().getGuiScaledHeight());
    }

    private static void draw(GuiGraphics g, int w, int h) {
        if (start < 0 || variant == null) return;
        long t = Util.getMillis() - start;
        if (t > DURATION_MS) { start = -1; return; }

        float fade = t < 500 ? 1f : Math.max(0f, 1f - (t - 500) / (float) (DURATION_MS - 500));
        g.fill(0, 0, w, h, ((int) (fade * 210) << 24) | 0x500000);               // destello rojo

        int i = variant.ordinal();
        int th = (int) (h * 1.15f * (1f + 0.05f * Math.sin(t * 0.03)));          // respira / se acerca
        int tw = (int) (th * (TEX_W[i] / (float) TEX_H[i]));
        int x = (w - tw) / 2 + (int) (Math.sin(t * 0.7) * 14 * fade);            // tiembla
        int y = (h - th) / 2 + (int) (Math.cos(t * 0.9) * 10 * fade);

        RenderSystem.enableBlend();
        g.setColor(1f, 1f, 1f, Math.min(1f, fade * 4f));
        g.blit(variant.texture, x, y, tw, th, 0, 0, TEX_W[i], TEX_H[i], TEX_W[i], TEX_H[i]);
        g.setColor(1f, 1f, 1f, 1f);
    }
}
