package com.nowheredreams.worldgen;

import com.nowheredreams.ModDimensions;
import com.nowheredreams.NowhereDreams;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Colinas redondas, casas retro y molinetes gigantes para la dimensión backrooms_92. */
public final class DreamFeatures {
    public static final DeferredRegister<Feature<?>> FEATURES = DeferredRegister.create(ForgeRegistries.FEATURES, NowhereDreams.MODID);

    public static final RegistryObject<Feature<NoneFeatureConfiguration>> HILL = FEATURES.register("hill", HillFeature::new);
    public static final RegistryObject<Feature<NoneFeatureConfiguration>> HOUSE = FEATURES.register("house", HouseFeature::new);
    public static final RegistryObject<Feature<NoneFeatureConfiguration>> PINWHEEL = FEATURES.register("pinwheel", PinwheelFeature::new);
    public static final RegistryObject<Feature<NoneFeatureConfiguration>> BETA_BOX = FEATURES.register("beta_box", BetaBoxFeature::new);

    /** La caja de Beta Lands: interior de -48 a 47 en X y Z, paredes de 2 bloques, techo en y=110. */
    public static final int BOX_R = 48, BOX_TOP = 110;

    /** Patrón de nubes (manchas elípticas) en coordenadas 2D de la pared o el techo. */
    private static boolean cloud(int a, int b, int salt) {
        int ca = Math.floorDiv(a, 9), cb = Math.floorDiv(b, 7);
        int h = (ca * 73856093) ^ (cb * 19349663) ^ (salt * 83492791);
        h ^= h >>> 13; h *= 0x5bd1e995; h ^= h >>> 15;
        if ((h & 7) >= 3) return false;
        double cx = ca * 9 + 3 + ((h >>> 3) & 3);
        double cy = cb * 7 + 3 + ((h >>> 5) & 1);
        double dx = (a - cx) / 4.2, dy = (b - cy) / 2.4;
        return dx * dx + dy * dy < 1;
    }

    private static void set(WorldGenLevel level, int x, int y, int z, BlockState state) {
        level.setBlock(new BlockPos(x, y, z), state, 2);
    }

    /** Primer hueco libre sobre el suelo (ignora aire y plantas), escaneando desde y=70. */
    private static int surface(WorldGenLevel level, int x, int z) {
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int y = 110; y >= level.getMinBuildHeight(); y--) {
            BlockState s = level.getBlockState(p.set(x, y, z));
            if (!s.isAir() && !s.canBeReplaced()) return y + 1;
        }
        return level.getMinBuildHeight();
    }

    // ---------------------------------------------------------------- colinas
    static class HillFeature extends Feature<NoneFeatureConfiguration> {
        HillFeature() { super(NoneFeatureConfiguration.CODEC); }

        @Override
        public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
            WorldGenLevel level = ctx.level();
            BlockPos o = ctx.origin();
            RandomSource rnd = ctx.random();
            boolean beta = level.getLevel().dimension() == ModDimensions.BETA;
            int r = 7 + rnd.nextInt(7);
            int hMax = 3 + rnd.nextInt(6);
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    double d = Math.sqrt(dx * dx + dz * dz);
                    if (d > r) continue;
                    int hh = (int) Math.round(hMax * 0.5 * (1 + Math.cos(Math.PI * d / r)));
                    if (hh <= 0) continue;
                    int x = o.getX() + dx, z = o.getZ() + dz;
                    if (beta && (x < -BOX_R || x >= BOX_R || z < -BOX_R || z >= BOX_R)) continue;
                    int y0 = surface(level, x, z);
                    if (y0 <= level.getMinBuildHeight() + 1) continue;
                    for (int i = 0; i < hh; i++)
                        set(level, x, y0 + i, z, (i == hh - 1 ? Blocks.GRASS_BLOCK : Blocks.DIRT).defaultBlockState());
                }
            }
            return true;
        }
    }

    // ---------------------------------------------------------------- casas
    static class HouseFeature extends Feature<NoneFeatureConfiguration> {
        private static final Block[] WALLS = {Blocks.WHITE_CONCRETE, Blocks.YELLOW_CONCRETE, Blocks.PINK_CONCRETE, Blocks.LIGHT_BLUE_CONCRETE};

        HouseFeature() { super(NoneFeatureConfiguration.CODEC); }

        @Override
        public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
            WorldGenLevel level = ctx.level();
            BlockPos o = ctx.origin();
            RandomSource rnd = ctx.random();
            int x0 = o.getX() - 3, z0 = o.getZ() - 3;

            int[] ss = {surface(level, x0, z0), surface(level, x0 + 6, z0), surface(level, x0, z0 + 6),
                    surface(level, x0 + 6, z0 + 6), surface(level, x0 + 3, z0 + 3)};
            int base = 0, low = Integer.MAX_VALUE;
            for (int v : ss) { base = Math.max(base, v); low = Math.min(low, v); }
            if (low <= level.getMinBuildHeight() + 1) return false; // sobre el vacío: no construir

            BlockState wall = WALLS[rnd.nextInt(WALLS.length)].defaultBlockState();
            BlockState floor = Blocks.OAK_PLANKS.defaultBlockState();
            BlockState found = Blocks.STONE_BRICKS.defaultBlockState();
            BlockState air = Blocks.AIR.defaultBlockState();
            BlockState glass = Blocks.GLASS.defaultBlockState();
            BlockState ridge = Blocks.BRICKS.defaultBlockState();

            for (int dx = 0; dx <= 6; dx++) {
                for (int dz = 0; dz <= 6; dz++) {
                    int x = x0 + dx, z = z0 + dz;
                    int s = surface(level, x, z);
                    for (int y = s - 1; y < base - 1; y++) set(level, x, y, z, found);
                    set(level, x, base - 1, z, floor);

                    boolean edge = dx == 0 || dx == 6 || dz == 0 || dz == 6;
                    for (int h = 0; h < 4; h++) {
                        BlockState st = edge ? wall : air;
                        if (dx == 3 && dz == 0 && h < 2) st = air;                              // puerta abierta
                        boolean window = h == 1 && (((dx == 0 || dx == 6) && dz == 3) || (dx == 3 && dz == 6));
                        if (window) st = glass;
                        set(level, x, base + h, z, st);
                    }

                    // tejado a dos aguas (cumbrera a lo largo de Z)
                    int rh = Math.min(dx, 6 - dx);
                    int ry = base + 4 + rh;
                    if (dx == 3) {
                        set(level, x, ry, z, ridge);
                    } else {
                        Direction up = dx < 3 ? Direction.EAST : Direction.WEST;
                        set(level, x, ry, z, Blocks.BRICK_STAIRS.defaultBlockState().setValue(StairBlock.FACING, up));
                    }
                    if (dz == 0 || dz == 6) // cierra los triángulos de los extremos
                        for (int y = base + 4; y < ry; y++) set(level, x, y, z, wall);
                }
            }
            if (level.getLevel().dimension() == ModDimensions.LIMINAL) { // la cama es la salida de Liminal Halls
                BlockState bed = Blocks.WHITE_BED.defaultBlockState().setValue(BedBlock.FACING, Direction.SOUTH);
                set(level, x0 + 2, base, z0 + 4, bed.setValue(BedBlock.PART, BedPart.FOOT));
                set(level, x0 + 2, base, z0 + 5, bed.setValue(BedBlock.PART, BedPart.HEAD));
            }
            return true;
        }
    }

    // ---------------------------------------------------------------- molinete gigante
    static class PinwheelFeature extends Feature<NoneFeatureConfiguration> {
        private static final Block[] BLADES = {Blocks.RED_CONCRETE, Blocks.YELLOW_CONCRETE, Blocks.LIGHT_BLUE_CONCRETE, Blocks.LIME_CONCRETE};

        PinwheelFeature() { super(NoneFeatureConfiguration.CODEC); }

        @Override
        public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
            WorldGenLevel level = ctx.level();
            BlockPos o = ctx.origin();
            RandomSource rnd = ctx.random();
            int x = o.getX(), z = o.getZ();

            int s = Math.max(Math.max(surface(level, x, z), surface(level, x + 1, z)),
                    Math.max(surface(level, x, z + 1), surface(level, x + 1, z + 1)));
            if (Math.min(Math.min(surface(level, x, z), surface(level, x + 1, z)),
                    Math.min(surface(level, x, z + 1), surface(level, x + 1, z + 1))) <= level.getMinBuildHeight() + 1) return false;
            int height = 16 + rnd.nextInt(7);
            BlockState pole = Blocks.WHITE_CONCRETE.defaultBlockState();

            for (int dx = 0; dx <= 1; dx++)
                for (int dz = 0; dz <= 1; dz++)
                    for (int y = s - 1; y < s + height; y++) set(level, x + dx, y, z + dz, pole);

            int hubY = s + height;
            BlockState hub = Blocks.ORANGE_CONCRETE.defaultBlockState();
            for (int dx = 0; dx <= 1; dx++)
                for (int dy = -1; dy <= 0; dy++)
                    for (int dz = 0; dz <= 1; dz++) set(level, x + dx, hubY + dy, z + dz, hub);

            double baseAngle = rnd.nextDouble() * Math.PI / 2;
            for (int i = 0; i < 4; i++) {
                double a = baseAngle + i * Math.PI / 2;
                double cos = Math.cos(a), sin = Math.sin(a);
                BlockState color = BLADES[i].defaultBlockState();
                for (int t = 1; t <= 10; t++) {
                    long wMax = Math.max(1, Math.round(t * 0.4));
                    for (int pw = 0; pw <= wMax; pw++) {
                        int bx = x + (int) Math.round(t * cos - pw * sin);
                        int by = hubY + (int) Math.round(t * sin + pw * cos);
                        for (int dz = 0; dz <= 1; dz++) set(level, bx, by, z + dz, color);
                    }
                }
            }
            return true;
        }
    }

    // ---------------------------------------------------------------- caja celeste de Beta Lands
    static class BetaBoxFeature extends Feature<NoneFeatureConfiguration> {
        BetaBoxFeature() { super(NoneFeatureConfiguration.CODEC); }

        @Override
        public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
            WorldGenLevel level = ctx.level();
            int cx = ctx.origin().getX() & ~15, cz = ctx.origin().getZ() & ~15; // chunk que se está generando
            BlockState sky = Blocks.LIGHT_BLUE_CONCRETE.defaultBlockState();
            BlockState cloud = Blocks.WHITE_CONCRETE.defaultBlockState();
            BlockState glass = Blocks.LIGHT_BLUE_STAINED_GLASS.defaultBlockState();
            BlockState cloudGlass = Blocks.WHITE_STAINED_GLASS.defaultBlockState();
            int R = BOX_R, minY = level.getMinBuildHeight();

            for (int dx = 0; dx < 16; dx++) {
                for (int dz = 0; dz < 16; dz++) {
                    int x = cx + dx, z = cz + dz;
                    if (x < -R - 2 || x >= R + 2 || z < -R - 2 || z >= R + 2) continue; // fuera de la caja
                    boolean inside = x >= -R && x < R && z >= -R && z < R;
                    if (inside) { // techo de vidrio celeste con nubes
                        set(level, x, BOX_TOP, z, cloud(x, z, 7) ? cloudGlass : glass);
                        continue;
                    }
                    boolean xWall = x < -R || x >= R;
                    int a = xWall ? z : x;
                    for (int y = minY; y <= BOX_TOP; y++)
                        set(level, x, y, z, cloud(a, y, xWall ? 3 : 5) ? cloud : sky);
                }
            }
            return true;
        }
    }

    private DreamFeatures() {}
}
